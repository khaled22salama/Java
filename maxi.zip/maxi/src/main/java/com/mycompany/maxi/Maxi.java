/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.maxi;

import java.util.Scanner;

/**
 *
 * @author khaled
 */
public class Maxi {

    public static void main(String[] args) {
         Scanner input=new Scanner(System.in);
        System.out.println("Hello");
       int n;
       System.out.println("enter size of array");
       n=input.nextInt();
       int arr[]=new int[n];
       int maxi=(int) -10e6;
       System.out.println("enter elements of array");
       for(int i=0;i<n;i++)
       {
           
           arr[i]=input.nextInt();
           if(arr[i]>maxi)
           {
               maxi=arr[i];
           }
           
       }
       System.out.println("maximum is: "+maxi);
    }
}

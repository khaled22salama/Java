/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.sumi;

import java.util.Scanner;

/**
 *
 * @author khaled
 */
public class Sumi {

    public static void main(String[] args) {
         Scanner scan= new Scanner(System.in);
           System.out.println("Hello");
           
           System.out.println("please enter n");
           int n=scan.nextInt();
               System.out.println("please enter r");
            int r=scan.nextInt();
                System.out.println("nCr = "+ nCr(n,r));
                System.out.println("nPr = "+ nPr(n,r));
            
           
        
    }
    
    
      public static int nCr(int n,int r){
       
        int fac=factorial(r);
       
        int npr=nPr(n,r);
               return npr/fac;
      
               
                
                
    }
      
      
      
       public static int nPr(int n,int r){
       int fac=factorial(n);
       int dec=factorial(n-r);
        
        return fac/dec;
                
    }
       
       public static int factorial(int n){
           for(int i=n-1;i>0;i--)
           {
               n*=i;
           }
           return n;
       }
               
}

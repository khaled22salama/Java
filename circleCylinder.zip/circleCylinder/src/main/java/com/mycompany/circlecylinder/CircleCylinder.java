/**
 * ***************************** Hello ^^__^^
 * ************************************** I am Khaled Abdelhamed Salama Student
 * at third year Section 2
 */
package com.mycompany.circlecylinder;

import java.util.Scanner;

/**
 *
 * @author khaled
 */
/////////////////////  Circle class /////////////
class Circle {

    private double radius = 1.0;
    private String color = "red";

    public Circle() {
    }

    public Circle(double radius, String color) {
        this.radius = radius;
        this.color = color;
    }

    public Circle(double radius) {
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }
    
  public void setRadius(double newRadius) {
        radius = newRadius;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String newColor) {
        color = newColor;
    }

    

    public String toString() {
        String pr = String.format("Color = %s, arc=%f", color, radius);
        return pr;
    }

    public double getArea() {
        return (radius * radius * 3.14);
    }

}


///////////////////////////  Cylinder class //////////////////////////
class Cylinder extends Circle {

    private double height = 1.0;

    public Cylinder() {
    }

    public Cylinder(double h) {
        height = h;
    }

    public Cylinder(double h, double radius, String color) {
        super(radius, color);
        height = h;
    }

    public Cylinder(double radius, double h) {
        super(radius);
        height = h;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double h) {
        height = h;
    }

    public double getVolume() {
        return super.getArea() * height;
    }

    @Override
    public String toString() {
        String pr = String.format("Color = %s, arc=%f, height=%f", super.getColor(), super.getRadius(), height);
        return pr;
    }

}

public class CircleCylinder {

    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
         boolean con = true;

        do {

            java.lang.System.out.println("******************************** Welcome! *******************************");
            java.lang.System.out.println("I am Khaled Salama\nHow can I help you?");

            java.lang.System.out.println("Do you need to play with circles Press 1 ");
            java.lang.System.out.println("Do you need to play with cylinder Press 2 ");
            

            int in = input.nextInt();
            switch (in) {
                case 1:
                    Circle cir = new Circle();
                    java.lang.System.out.println("Please enter radius");
                    double x = input.nextDouble();
                    cir.setRadius(x);
                    
                    java.lang.System.out.println("Please enter color");
                    String c = input.next();
                    cir.setColor(c);
                    java.lang.System.out.println("------------------------------------------");
                    System.out.println(cir.toString());
                    System.out.printf("Area of circle = %f\n",cir.getArea());

                    

                 

                    break;
                case 2:
                    //print all flights
                   Cylinder cyl = new Cylinder();
                    java.lang.System.out.println("Please enter radius");
                    double y = input.nextDouble();
                    cyl.setRadius(y);
                    
                    java.lang.System.out.println("Please enter height");
                    double h = input.nextDouble();
                    cyl.setHeight(h);
                    
                    
                    java.lang.System.out.println("Please enter color");
                    String k = input.next();
                    cyl.setColor(k);
                    System.out.println("------------------------------------------");
                    System.out.println(cyl.toString());
                    System.out.printf("Volume of cylinder = %f\n",cyl.getVolume());
                    break;
                
                default:
                    java.lang.System.out.println("Your number not valid ");

            }
            //repeat program again
            java.lang.System.out.println("Wanna ask again press y and n if you need to exit ");
            char s = input.next().charAt(0);
            if (s == 'N' || s == 'n') {
                con = false;
            }

        } while (con);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shape;
import java.lang.Math;

/**
 *
 * @author khaled
 */
public class Data {
    double arc;
    double first_tri;
    double sec_tri;
    double th_tri;
    
    public double tri_peri()
    {
        return (first_tri+sec_tri+th_tri);
    }
    public double cir_peri()
    {
        return (2*arc*3.14);
    }
    public double tri_area()
    {
        double hlf=(tri_peri()/2);
        

        double sq=(hlf*(hlf-first_tri)*(hlf-sec_tri)*(hlf-th_tri));
        return (Math.sqrt(sq));
    }
    public double cir_area()
    {
        return (arc*arc*3.14);
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.shape;

import java.util.Scanner;

/**
 *
 * @author khaled
 */
public class Shape {

    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        Data dt=new Data();
        System.out.println("Hello");
        System.out.println("enter arc of circle");
        dt.arc=input.nextDouble();
        System.out.printf("perimeter of circle is: %ff\n",dt.cir_peri());
        System.out.printf("area of circle is: %ff\n",dt.cir_area());
        
        
        
        
         System.out.println("enter first side of triangle");
        dt.first_tri=input.nextDouble();
         System.out.println("enter secont side of triangle");
        dt.sec_tri=input.nextDouble();
         System.out.println("enter third side of triangle");
        dt.th_tri=input.nextDouble();
        System.out.printf("perimeter of triangle is: %ff\n",dt.tri_peri());
        System.out.printf("area of triangle is: %ff\n",dt.tri_area());
        
    }
}

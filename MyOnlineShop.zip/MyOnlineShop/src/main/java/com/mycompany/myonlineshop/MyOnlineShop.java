/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.myonlineshop;

import java.util.Scanner;

/**
 *
 * @author khaled
 */



interface  Product{
    public abstract void setPrice(double newPrice);
    public abstract double getPrice();
    
}


class Book implements Product{
   
    double price;
    
    public  void setPrice(double newPrice){
        this.price=newPrice;
    }
    
    
    public  double getPrice(){
        return price*0.8;
    }
    
}
class Children implements Product{
    double price;
    
    @Override
    public  void setPrice(double newPrice){
        this.price=newPrice;
    }
    
    @Override
    public  double getPrice(){
        return price*0.6;
    }
    
}



class Cartoon implements Product{
    double price;
    @Override
    public  void setPrice(double newPrice){
        this.price=newPrice;
    }
    
    @Override
    public  double getPrice(){
        return price*0.4 ;
    }
    
}

public class MyOnlineShop {

    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.println("Hello!");
        Product p1[]=new Product[3];
        p1[0]=new Book();
        p1[1]=new Children();
        p1[2]=new Cartoon(); 
        double x;
        java.lang.System.out.println("Please enter book price");
        x=input.nextDouble();
        p1[0].setPrice(x);
        System.out.println("price of book is "+p1[0].getPrice());
        
        
        java.lang.System.out.println("Please enter children price");
        x=input.nextDouble();
        p1[1].setPrice(x);
        System.out.println("price of children book is "+p1[1].getPrice());
        
        
        
        
         java.lang.System.out.println("Please enter cartoon book price");
        x=input.nextDouble();
         p1[2].setPrice(x);
        System.out.println("price of cartoon book is "+p1[2].getPrice());
        
    }
}

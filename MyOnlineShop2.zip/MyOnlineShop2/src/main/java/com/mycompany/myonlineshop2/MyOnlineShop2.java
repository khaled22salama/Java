/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.myonlineshop2;

import java.util.Scanner;

/**
 *
 * @author khaled
 */


abstract class Product{
    double price;
    public abstract void setPrice(double newPrice);
    public abstract double getPrice();
    
    
}



class Book extends Product{
   
    
    @Override
    public  void setPrice(double newPrice){
        this.price=newPrice;
    }
    
    @Override
    public  double getPrice(){
        return price*0.8;
    }
    
}
class Children extends Product{
    @Override
    public  void setPrice(double newPrice){
        this.price=newPrice;
    }
    
    @Override
    public  double getPrice(){
        return price*0.6;
    }
    
}


public class MyOnlineShop2 {

    public static void main(String[] args) {
         Scanner input=new Scanner(System.in);
        System.out.println("Hello!");
        Product p1[]=new Product[2];
        p1[0]=new Book();
        p1[1]=new Children();
        
        double x;
        java.lang.System.out.println("Please enter book price");
        x=input.nextDouble();
        p1[0].setPrice(x);
        System.out.println("price of book is "+p1[0].getPrice());
        
        
        java.lang.System.out.println("Please enter children price");
        x=input.nextDouble();
        p1[1].setPrice(x);
        System.out.println("price of children book is "+p1[1].getPrice());
        
        
        
        
         
    }
}

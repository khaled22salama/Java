/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.transpose;

import java.util.Scanner;

/**
 *
 * @author khaled
 */
public class Transpose {
    
    static int[][] trans(int a[][],int r,int c)
    {
        int [][]newArr=new int[c][r];
        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
            {
                newArr[j][i]=a[i][j];
            }
        }
        return newArr;
        
    }

    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        int row,col;
        System.out.println("Hello");
        System.out.println("enter number of rows");
        row=input.nextInt();
        System.out.println("enter number of coloums");
        col=input.nextInt();
        
        
        int [][]arr=new int[row][col];
        System.out.println("enter elements of array");
        for(int i=0;i<row;i++)
        {
            System.out.println("enter elements of row "+i);
            for(int j=0;j<col;j++)
            {
                arr[i][j]=input.nextInt();
            }
        }
        int [][]one=trans(arr,row,col);
          System.out.println("the new array");
        for(int i=0;i<row;i++)
        {
            
            for(int j=0;j<col;j++)
            {
                System.out.printf("%d , ",one[i][j]);
            }
            System.out.println("");
        }
        
        
    }
}

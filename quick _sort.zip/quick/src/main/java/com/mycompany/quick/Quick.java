/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.quick;

import java.util.Scanner;

/**
 *
 * @author khaled
 */
public class Quick {
    
    static void quc(int[] arr,int s,int e)
    {
        if(s>=e)return;
        int mid=s+(e-s)/2;
        int pov=arr[mid];
        int i=s;
        int j=e;
        while(i<=j)
        {
            while(arr[i]<pov)
            {
                i++;
            }
            while(arr[j]>pov)
            {
                j--;
            }
            if(i<j)
            {
                int rep=arr[i];
                arr[i]=arr[j];
                arr[j]=rep;
                i++;
                j--;
                
            }
        }
        if(s<j)
        {
            quc(arr,s,j);
        }
        if(e>i)
        {
            quc(arr,i,e);
        }
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Hello! Wanna play?!");
        System.out.println("please enter size of array");
        int n = input.nextInt();
        int arr[] = new int[n];
        
        
        System.out.println("please enter elements of array");
        for (int i = 0; i < n; i++) {
            arr[i] = input.nextInt();
        }
            quc(arr,0,n-1);
            System.out.println("please enter elements of array");
        for (int i = 0; i < n; i++) {
           System.out.printf(" %d , ",arr[i]);
        }

    }
}

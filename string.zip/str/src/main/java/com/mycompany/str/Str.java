/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.str;

import java.util.Scanner;

/**
 *
 * @author khaled
 */
public class Str {

    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        
        String str;
        System.out.println("enter sentence");
        str=input.next();
        str=str.replaceAll(",","");
         System.out.printf("output is: %s",str);
        
        
        
    }
}

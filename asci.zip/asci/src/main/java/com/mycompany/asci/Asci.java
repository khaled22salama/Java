/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.asci;

import java.util.Scanner;

/**
 *
 * @author khaled
 */
public class Asci {

    public static void main(String[] args) {
         Scanner input = new Scanner(System.in); //scan object

        
        //enter charcheter  then output ASCI
        System.out.println("Enter charchter");
        
        char x = input.next().charAt(0);
        System.out.println((int) x);
        
        //enter ASCI then output charcheter
        System.out.println("Enter number");
        int y = input.nextInt();
        char z = (char) y;
        System.out.println(z);
    }
}
